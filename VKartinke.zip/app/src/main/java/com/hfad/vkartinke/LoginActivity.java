package com.hfad.vkartinke;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class LoginActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        WebView webView = (WebView) findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        class SimpleWebViewClient extends WebViewClient {

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, String url) {
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (url.contains("access_token=") && url.contains("user_id="))
                {
                    int access_token_begin = url.indexOf("access_token=") + 13; // access_token= смещение
                    int access_token_end = url.indexOf('&');
                    int user_id_begin = url.indexOf("user_id=") + 8; // user_id= смещение
                    String user_id = url.substring(user_id_begin);
                    String access_token = url.substring(access_token_begin, access_token_end);
                    Intent intent = new Intent(LoginActivity.this, PreviewActivity.class);
                    intent.putExtra("access_token", access_token);
                    intent.putExtra("user_id", user_id);
                    startActivity(intent);
                }
            }
        }
        SimpleWebViewClient webViewClient = new SimpleWebViewClient();
        webView.setWebViewClient(webViewClient);
        webView.loadUrl("https://oauth.vk.com/authorize?client_id=5490057&display=page" +
                        "&redirect_uri=https://oauth.vk.com/blank.html&scope=photos&" +
                        "response_type=token&v=5.52");
    }
}
