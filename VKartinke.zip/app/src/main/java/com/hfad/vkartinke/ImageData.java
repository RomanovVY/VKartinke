package com.hfad.vkartinke;

import android.os.Parcel;
import android.os.Parcelable;

public class ImageData implements Parcelable
{
    private String text, MaxSizeLink, likes,reposts;


    public ImageData(String text, String MaxSizeLink, String likes, String reposts)
    {
        this.text = text;
        this.MaxSizeLink = MaxSizeLink;
        this.likes = likes;
        this.reposts = reposts;
    }

    ImageData(Parcel in)
    {
        this.text = in.readString();
        this.MaxSizeLink = in.readString();
        this.likes = in.readString();
        this.reposts = in.readString();
    }

    public void setText (String text)
    {
        this.text = text;
    }

    public void setMaxSizeLink (String MaxSizeLink)
    {
        this.MaxSizeLink = MaxSizeLink;
    }

    public void setLikes (String likes)
    {
        this.likes = likes;
    }

    public void setRepost (String reposts)
    {
        this.reposts = reposts;
    }

    public String getMaxSizeLink ()
    {
        return this.MaxSizeLink;
    }

    public String getText()
    {
        return  this.text;
    }

    public String getLikes ()
    {
        return  this.likes;
    }

    public  String getRepost ()
    {
        return this.reposts;
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeString( text);
        dest.writeString(MaxSizeLink);
        dest.writeString(likes);
        dest.writeString(reposts);
    }
    public static final Creator<ImageData> CREATOR = new Creator<ImageData>() {

        @Override
        public ImageData createFromParcel(Parcel source) {
            return new ImageData(source);
        }

        @Override
        public ImageData[] newArray(int size) {
            return new ImageData[size];
        }
    };
}
