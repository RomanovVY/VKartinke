package com.hfad.vkartinke;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PreviewActivity extends Activity {
    String access_token, user_id;
    GridView gridview;
    final static String version = "v=5.62";
    final static String method = "https://api.vk.com/method/photos.getAll";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);
        Intent intent = getIntent();
        access_token = intent.getExtras().getString("access_token");
        user_id = intent.getExtras().getString("user_id");
        gridview = (GridView)findViewById(R.id.gridView);
        previewBuilding();
    }

    public void previewBuilding ()
    {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(method+"?count=1&offset=0"
                        +"&owner_id="+user_id
                        +"&access_token="+access_token
                        +'&'+version)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                }
                else
                {
                    String resp = response.body().string();
                    int totalNumberOfImage = 0;
                    try {
                        JSONObject Resp = new JSONObject(resp);
                        JsonParsing numberOfImage = new JsonParsing(Resp);
                        totalNumberOfImage = numberOfImage.numberOfImages();
                    }

                    catch (JSONException e){
                        e.printStackTrace();
                    }
                    Timer mTimer = new Timer();
                    RequestImages mRequestImages = new RequestImages(totalNumberOfImage);
                    mTimer.schedule(mRequestImages, 340, 340);
                }
            }
        });

    }

    private class RequestImages extends TimerTask
    {
        private int totalImage;
        private ArrayList imageDataList = new ArrayList();
        private ArrayList imageLinks = new ArrayList();
        private int toEnding;
        private int  offset = 0;
        private RequestImages (int totalImages) {
            this.totalImage = totalImages;
            this.toEnding = totalImages;
        }
        OkHttpClient client = new OkHttpClient();
        private String doGetRequest(String url) throws IOException {
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Response response = client.newCall(request).execute();
            return response.body().string();
        }
        @Override
        public void run()
        {

            String response = new String();
            String url = method+'?'
                    +"extended=1&count=200&offset="+offset
                    +"&owner_id="+user_id
                    +"&access_token="+access_token
                    +'&'+version;
            try {
                response = doGetRequest(url);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            try {
                JSONObject ResponseJson = new JSONObject(response);
                JsonParsing Links = new JsonParsing(ResponseJson);
                Links.previewImageLinks(imageLinks);
                Links.imageDataList(imageDataList);
            }
            catch (JSONException e){
                e.printStackTrace();
            }
            toEnding = toEnding - 200;
            offset = offset + 200;
            if (toEnding < 0) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        gridview.setAdapter(new ImageAdapter(PreviewActivity.this, totalImage, imageLinks));
                        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                                Intent i = new Intent(getApplicationContext(), FullScreenActivity.class);
                                i.putExtra("id", position);
                                i.putExtra("access_token", access_token);
                                i.putExtra("used_id", user_id);
                                i.putExtra("imageInfo", imageDataList);
                                startActivity(i);
                            }
                        });
                    }
                });
                cancel();
            }
        }
    }
}