package com.hfad.vkartinke;

import android.content.Context;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ImageAdapter extends BaseAdapter {
    private Context context;
    int totalImage;
    ArrayList imageLinksArray;

    public ImageAdapter(Context context, int totalImage, ArrayList imageLinksArray)
    {
        this.imageLinksArray = imageLinksArray;
        this.context = context;
        this.totalImage = totalImage;
    }

    public int getCount() {
        return totalImage;
    }

    @Override
    public String getItem(int position)
    {
        return imageLinksArray.get(position).toString();
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        int width = display.getWidth() - 32; // Вычитаем отступы
        int imageWidth = width/3;
        if (convertView == null)
        {
            imageView = new ImageView(context);
            imageView.setLayoutParams(new GridView.LayoutParams(imageWidth, imageWidth));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        }
        else
            imageView = (ImageView) convertView;
        String url = getItem(position);
        Picasso.with(context)
                .load(url)
                .resize (imageWidth, imageWidth)
                .into(imageView);
        return imageView;
    }
}