package com.hfad.vkartinke;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonParsing {

    JSONObject response;

    JsonParsing(JSONObject response) {
        this.response = response;
    }

    public ArrayList imageDataList (ArrayList ImageInfo){
        try {
            JSONObject responseParsing = response.getJSONObject("response");
            JSONArray items = responseParsing.getJSONArray("items");
            String tmpPhotoLink;
            for (int i = 0; i<items.length(); i++) {
                if(items.getJSONObject(i).has("photo_2560"))
                    tmpPhotoLink = items.getJSONObject(i).getString("photo_2560");
                else if (items.getJSONObject(i).has("photo_1280"))
                    tmpPhotoLink = items.getJSONObject(i).getString("photo_1280");
                else if (items.getJSONObject(i).has("photo_807"))
                    tmpPhotoLink = items.getJSONObject(i).getString("photo_807");
                else
                    tmpPhotoLink = items.getJSONObject(i).getString("photo_604");
                ImageInfo.add(new ImageData(items.getJSONObject(i).getString("text"),
                                        tmpPhotoLink,
                                        items.getJSONObject(i).getJSONObject("likes").getString("count"),
                                        items.getJSONObject(i).getJSONObject("reposts").getString("count")));
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        return ImageInfo;
    }

    public ArrayList previewImageLinks (ArrayList imageLinks) {
        try {
            JSONObject responseParsing = response.getJSONObject("response");
            JSONArray items = responseParsing.getJSONArray("items");
            for (int i = 0; i<items.length(); i++) {
                imageLinks.add(items.getJSONObject(i).getString("photo_604"));
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        return imageLinks;
    }

    public int numberOfImages() {
        int answer = 0;
        try {
            JSONObject responseParsing = response.getJSONObject("response");
            answer = responseParsing.getInt("count");
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        return answer;
    }
}
