package com.hfad.vkartinke;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class FullScreenActivity extends Activity implements View.OnTouchListener {

    private int position;
    private float fromPosition = 0;
    private boolean imageInfoLayout = false;
    private ArrayList ImageList = new ArrayList();
    private ImageView img;
    private TextView text, likesCount, repostsCount, imageCount;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen);

        Intent intent = getIntent();
        position = intent.getExtras().getInt("id");
        ImageList = intent.getExtras().getParcelableArrayList("imageInfo");
        img = (ImageView)findViewById(R.id.image);
        text = (TextView)findViewById(R.id.text);
        likesCount = (TextView)findViewById(R.id.likes_count);
        repostsCount = (TextView)findViewById(R.id.repostsCount);
        imageCount = (TextView)findViewById(R.id.imageCount);
        ShowImage();
        img.setOnTouchListener(this);
    }
    @Override
    public boolean onTouch (View v, MotionEvent event)
    {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                fromPosition = event.getX();
                break;
            case MotionEvent.ACTION_UP:
                float toPosition = event.getX();
                if (Math.abs(fromPosition - toPosition) > 10)
                {
                    if (fromPosition > toPosition)
                    {
                        if (position < ImageList.size() - 1)
                            position = position + 1;
                    }
                    else if (  position > 0)
                        position = position - 1;

                    ShowImage();
                }
                else
                {
                    if (imageInfoLayout)
                    {
                        findViewById(R.id.information_bottom).setVisibility(View.INVISIBLE);
                        findViewById(R.id.information_top).setVisibility(View.INVISIBLE);
                    }
                    else
                    {
                        findViewById(R.id.information_bottom).setVisibility(View.VISIBLE);
                        findViewById(R.id.information_top).setVisibility(View.VISIBLE);
                    }
                    imageInfoLayout = !imageInfoLayout;
                }
                break;

        }
        return true;
    }
    public void ShowImage()
    {
        ImageData currentImage = ((ImageData) ImageList.get(position));
        Picasso.with(this) //передаем контекст приложения
                .load(currentImage.getMaxSizeLink()) //адрес изображения
                .into(img); //ссылка на ImageView
        if (!currentImage.getText().isEmpty())
            text.setText("Описание: "+currentImage.getText());
        else
            text.setText("");
        likesCount.setText(currentImage.getLikes());
        repostsCount.setText(currentImage.getRepost());
        imageCount.setText("Фотография " + (position+1) + " из " + ImageList.size());
    }

    public void backClick(View view)
    {
        this.finish();
    }
}
